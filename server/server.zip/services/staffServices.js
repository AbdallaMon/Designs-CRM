import prisma from "../prisma/prisma.js";
import dayjs from "dayjs";
import {
    newCallNotification,
    newFileUploaded,
    newNoteNotification,
    newPriceOffer,
    updateCallNotification
} from "./notification.js";
import {updateLead} from "./utility.js";

export async function createNote({clientLeadId, userId, content}) {
    if (!content.trim()) {
        throw new Error('Note content cannot be empty.');
    }

    const newNote = await prisma.note.create({
        data: {
            content,
            clientLeadId,
            userId,
        },
        select: {
            id: true,
            createdAt: true,
            user: {
                select: {
                    id:true,
                    name: true
                }
            }
        }
    });
    await updateLead(clientLeadId)
    newNote.content = content
    await newNoteNotification(clientLeadId,content,newNote.user.id)
    return newNote;
}

export async function createCallReminder({clientLeadId, userId, time, reminderReason}) {
    let formattedTime = dayjs(time);
    if (formattedTime.isBefore(dayjs())) {
        throw new Error('The reminder time must be in the future.');
    }
    formattedTime = formattedTime.toISOString()
    const newReminder = await prisma.callReminder.create({
        data: {
            clientLeadId,
            userId,
            time: formattedTime,
            reminderReason,
        },
        select: {
            id: true,
            time: true,
            status: true,
            reminderReason: true,
            callResult: true,
            userId: true,
            user: {
                select: {name: true},
            },
        },

    });
    await  newCallNotification(clientLeadId,newReminder)
    let latestTwo = await prisma.callReminder.findMany({
        where: {
            clientLeadId,
        },
        orderBy: {time: 'desc'},
        take: 2,
    })
    await updateLead(clientLeadId)
    return {latestTwo, newReminder}
}

export async function createPriceOffer({clientLeadId, userId, priceOffer}) {
    if (priceOffer.minPrice > priceOffer.maxPrice) {
        throw new Error('End price must be bigger or equal to start price');
    }
    const newPrice = await prisma.PriceOffers.create({
        data: {
            clientLeadId,
            userId,
            minPrice: Number(priceOffer.minPrice),
            maxPrice: Number(priceOffer.maxPrice),
            url:priceOffer.url
        },
        select: {
            id: true,
            createdAt: true,
            minPrice: true,
            maxPrice: true,
            url:true,
            user: {
                select: {
                    id:true,
                    name: true
                }
            }
        }
    });
    await updateLead(clientLeadId)
    await newPriceOffer(clientLeadId,newPrice)
    return newPrice;
}

export async function createFile({clientLeadId, url, name, description, userId}) {

    if (!url || !name || !description) {
        throw new Error('Fill all the fields please');
    }
    const data = {
        name,
        clientLeadId,
        url,
        description,
    }
    if (userId) {
        data.userId = Number(userId)
    }
    const file = await prisma.file.create({
        data,
        select: {
            id: true,
            createdAt: true,
            user: {
                select: {
                    name: true
                }
            }
        }
    });
    if(userId!==null){
await newFileUploaded(clientLeadId,data,userId)
    }
    await updateLead(clientLeadId)
    return {...file, name, url, description, isUserFile: userId !== null};
}


export async function updateCallReminderStatus({reminderId,currentUser, status, callResult = null}) {
    const updatedReminder = await prisma.callReminder.update({
        where: {id: reminderId},
        data: {
            status,
            callResult: status === 'DONE' ? callResult : "Missed call",
        },
        select: {
            id: true,
            time: true,
            status: true,
            reminderReason: true,
            callResult: true,
            userId: true,
            clientLeadId:true,
            user: {
                select: {name: true},
            },
        },

    });
    await updateLead(updatedReminder.clientLeadId)
    await updateCallNotification(updatedReminder.clientLeadId,updatedReminder,currentUser.id)
    return updatedReminder;
}


export const getCallReminders = async (searchParams) => {
    const staffFilter = searchParams.staffId ? {userId: Number(searchParams.staffId)} : {};

    try {
        const callReminders = await prisma.callReminder.findMany({
            where: {
                clientLead: {
                    status: {
                        notIn: ['CONVERTED', 'ON_HOLD', 'FINALIZED', 'REJECTED'],
                    },
                    ...staffFilter,
                },
                status: 'IN_PROGRESS',
            },
            include: {
                clientLead: {
                    select: {
                        client: {
                            select: {
                                name: true,
                            },
                        },
                    },
                },
            },
        });

        return callReminders;
    } catch (error) {
        console.error('Error fetching call reminders:', error);
        throw new Error('Unable to fetch call reminders');
    }
};

